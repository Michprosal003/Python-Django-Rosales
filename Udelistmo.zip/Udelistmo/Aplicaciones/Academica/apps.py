from django.apps import AppConfig


class AcademicaConfig(AppConfig):
    name = 'Academica'
