from django.urls import path
from .import views

urlpatterns = [
    path('', views.home),
    path('agregarCurso/', views.agregarCurso),
    path('eliminar_Curso/<codigo>', views.eliminar_Curso),
    path('edicion_Curso/<codigo>', views.edicion_Curso),
    path('editar_Curso/', views.editar_Curso),
    path('paginacion/', views.paginacion)









]
