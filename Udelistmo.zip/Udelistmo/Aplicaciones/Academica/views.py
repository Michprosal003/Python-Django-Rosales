from django.shortcuts import render, redirect
from .models import Estudiante
from django.contrib import messages
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


# Create your views here.


def paginacion(request):
    ListaEstudiantes = Estudiante.objects.all()
    page = request.GET.get('page', 1)

    paginator = Paginator(ListaEstudiantes, 5)
    try:
        estudiantes = paginator.page(page)
    except PageNotAnInteger:
        estudiantes = paginator.page(1)
    except EmptyPage:
        estudiantes = paginator.page(paginator.num_pages)

    return render(request, "paginacion.html", {"estudiantes": estudiantes})


def home(request):
    Listadosestudiantes = Estudiante.objects.all()
    return render(request, "Curso.html", {"estudiantes": Listadosestudiantes})


def agregarCurso(request):
    codigo = request.POST['txtCodigo']
    nombre = request.POST['txtNombre']
    materia = request.POST['txtMateria']
    nota = request.POST['txtNota']
    jornada = request.POST['txtJornada']
    estado = request.POST['txtEstado']

    curso = Estudiante.objects.create(
        codigo=codigo, nombre=nombre, materia=materia, nota=nota, jornada=jornada, estado=estado)
    messages.success(request, 'Curso registrado correctamente')
    return redirect('/')


def eliminar_Curso(request, codigo):
    curso = Estudiante.objects.get(codigo=codigo)
    curso.delete()

    messages.success(request, 'Curso Eliminado')
    return redirect('/')


def edicion_Curso(request, codigo):
    curso = Estudiante.objects.get(codigo=codigo)
    return render(request, "edicion_Curso.html", {"curso": curso})


def editar_Curso(request):
    codigo = request.POST['txtCodigo']
    nombre = request.POST['txtNombre']
    materia = request.POST['txtMateria']
    nota = request.POST['txtNota']
    jornada = request.POST['txtJornada']
    estado = request.POST['txtEstado']

    curso = Estudiante.objects.get(codigo=codigo)
    curso.nombre = nombre
    curso.materia = materia
    curso.nota = nota
    curso.jornada = jornada
    curso.estado = estado
    curso.save()

    messages.success(request, 'Curso actualizado')
    return redirect('/')
