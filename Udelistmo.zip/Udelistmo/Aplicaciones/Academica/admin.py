from django.contrib import admin
from .models import Estudiante

# Register your models here.


admin.site.register(Estudiante)
